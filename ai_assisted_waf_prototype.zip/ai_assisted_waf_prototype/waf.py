import re, urllib.parse, pickle
from pathlib import Path
MODEL_PATH = Path(__file__).parent / "model.pkl"
THRESHOLD = 0.60
RULES = {
 "SQLi": [r"(?i)(?:'|%27)\s*(?:or|and)\s+['\w\d]+\s*=\s*['\w\d]+", r"(?i)\b\d+\s+(?:or|and)\s+\d+\s*=\s*\d+", r"(?i)\bunion\s+(?:all\s+)?select\b", r"(?i)\bselect\b.+\bfrom\b", r"(?i)\b(?:drop|delete|insert|update)\s+(?:table|into)?\s*\w+", r"(?i)(?:--|/\*|\*/|;)\s*(?:$|or\b|select\b|drop\b)"],
 "XSS": [r"(?i)<\s*script\b", r"(?i)<\s*(?:svg|img|iframe)\b[^>]*(?:onerror|onload|src\s*=\s*['\"]?javascript:)", r"(?i)javascript\s*:", r"(?i)\bon(?:error|load|click)\s*="],
 "Command Injection": [r"(?i)(?:;|\|\||&&|\|)\s*(?:cat|id|whoami|uname|pwd|ls|curl|wget)\b", r"(?i)`\s*(?:id|whoami|uname|cat|pwd)\b[^`]*`", r"\$\(\s*(?:id|whoami|uname|cat|pwd)\b"]
}
def normalize(s):
    s = str(s or "")
    for _ in range(2):
        t = urllib.parse.unquote_plus(s)
        if t == s: break
        s = t
    return s
def detect_rules(s):
    s = normalize(s)
    return [name for name, patterns in RULES.items() if any(re.search(p, s) for p in patterns)]
def load_model():
    if not MODEL_PATH.exists(): return None
    with MODEL_PATH.open("rb") as f: return pickle.load(f)
def inspect_request(request_text, model=None, threshold=THRESHOLD):
    normalized = normalize(request_text)
    rules = detect_rules(normalized)
    model = model if model is not None else load_model()
    prob, ml_label = None, "unavailable"
    if model is not None:
        prob = float(model.predict_proba([normalized])[0][1])
        ml_label = "malicious" if prob >= threshold else "benign"
    blocked = bool(rules) or ml_label == "malicious"
    reason = ("Rule match: " + ", ".join(rules)) if rules else (f"ML score {prob:.3f} >= {threshold:.2f}" if ml_label == "malicious" else "No rule matched; ML classified request as benign")
    return {"request":str(request_text), "rule_matches":rules, "ml_label":ml_label,
            "malicious_probability":round(prob,4) if prob is not None else None,
            "decision":"BLOCK" if blocked else "ALLOW", "reason":reason}
