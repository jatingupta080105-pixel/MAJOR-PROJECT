from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse,parse_qs
from html import escape
import json
from waf import inspect_request
HOST,PORT="127.0.0.1",8080
PAGE="""<!doctype html><meta charset=utf-8><title>AI-Assisted WAF</title>
<style>body{font:16px system-ui;max-width:850px;margin:40px auto;background:#f4f6fa;color:#182230;padding:0 20px}.card{background:white;padding:22px;border:1px solid #ddd;border-radius:12px;margin:16px 0}textarea{width:100%;height:90px}button{padding:10px 16px;background:#19365d;color:white;border:0;border-radius:6px}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#edf1f6;padding:14px}</style>
<h1>AI-Assisted Web Application Firewall</h1><p>Hybrid request inspection: rule engine + TF-IDF/Logistic Regression</p>
<div class=card><form method=post action=/inspect><label>HTTP-style request or URL</label><p><textarea name=request>/products?id=25</textarea></p><button>Inspect request</button></form></div>
<div class=card><h3>Try these examples</h3><p>/products?id=25</p><p>/products?id=1%20OR%201=1</p><p>/?q=%3Cscript%3Ealert(1)%3C/script%3E</p><p>/?file=%3Bcat%20/etc/passwd</p></div>"""
class H(BaseHTTPRequestHandler):
 def send(self,body,status=200,ctype="text/html; charset=utf-8"):
  b=body.encode(); self.send_response(status); self.send_header("Content-Type",ctype); self.send_header("Content-Length",str(len(b))); self.send_header("X-Content-Type-Options","nosniff"); self.end_headers(); self.wfile.write(b)
 def do_GET(self):
  if urlparse(self.path).path=="/health": self.send('{"status":"ok"}',ctype="application/json")
  else: self.send(PAGE)
 def do_POST(self):
  if urlparse(self.path).path!="/inspect": return self.send("Not found",404)
  n=min(int(self.headers.get("Content-Length","0")),20000); raw=self.rfile.read(n).decode(errors="replace")
  req=parse_qs(raw,keep_blank_values=True).get("request",[""])[0][:5000]
  result=inspect_request(req)
  with open("waf_events.jsonl","a",encoding="utf-8") as f: f.write(json.dumps(result)+"\n")
  color="#a11" if result["decision"]=="BLOCK" else "#17643b"
  out=PAGE+f'<div class="card"><h2 style="color:{color}">{escape(result["decision"])}</h2><pre>{escape(json.dumps(result,indent=2))}</pre></div>'
  self.send(out)
 def log_message(self,fmt,*args): print(fmt%args)
if __name__=="__main__":
 print(f"Local demo: http://{HOST}:{PORT} (Ctrl+C to stop)")
 HTTPServer((HOST,PORT),H).serve_forever()
