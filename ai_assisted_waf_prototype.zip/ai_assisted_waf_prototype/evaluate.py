from pathlib import Path
import json,time,pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score,precision_score,recall_score,f1_score,confusion_matrix
ROOT=Path(__file__).parent
df=pd.read_csv(ROOT/"dataset/synthetic_requests.csv").dropna()
X=df.request.astype(str); y=(df.label=="malicious").astype(int)
Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=.30,random_state=42,stratify=y)
m=Pipeline([("tfidf",TfidfVectorizer(analyzer="char",ngram_range=(2,5),sublinear_tf=True)),("classifier",LogisticRegression(max_iter=2000,class_weight="balanced",random_state=42))])
m.fit(Xtr,ytr); t=time.perf_counter(); p=m.predict(Xte); ms=(time.perf_counter()-t)*1000
result={"dataset":"small synthetic educational dataset","total_examples":len(df),"train_examples":len(Xtr),"test_examples":len(Xte),
"accuracy":round(float(accuracy_score(yte,p)),4),"precision_malicious":round(float(precision_score(yte,p,zero_division=0)),4),
"recall_malicious":round(float(recall_score(yte,p,zero_division=0)),4),"f1_malicious":round(float(f1_score(yte,p,zero_division=0)),4),
"confusion_matrix_labels":["benign","malicious"],"confusion_matrix":confusion_matrix(yte,p,labels=[0,1]).tolist(),
"prediction_elapsed_ms_total":round(ms,3),"prediction_elapsed_ms_per_request":round(ms/max(1,len(Xte)),4),
"caveat":"Metrics apply only to this small synthetic dataset; do not generalize to real traffic."}
(ROOT/"results").mkdir(exist_ok=True)
(ROOT/"results/metrics.json").write_text(json.dumps(result,indent=2))
pd.DataFrame({"request":Xte,"actual":yte.map({0:"benign",1:"malicious"}),"predicted":pd.Series(p,index=Xte.index).map({0:"benign",1:"malicious"})}).to_csv(ROOT/"results/predictions.csv",index=False)
print(json.dumps(result,indent=2))
