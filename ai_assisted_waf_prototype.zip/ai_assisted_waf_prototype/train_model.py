from pathlib import Path
import pickle, pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
ROOT=Path(__file__).parent
df=pd.read_csv(ROOT/"dataset/synthetic_requests.csv").dropna()
model=Pipeline([("tfidf",TfidfVectorizer(analyzer="char",ngram_range=(2,5),sublinear_tf=True)),
                ("classifier",LogisticRegression(max_iter=2000,class_weight="balanced",random_state=42))])
model.fit(df.request.astype(str),(df.label=="malicious").astype(int))
with (ROOT/"model.pkl").open("wb") as f: pickle.dump(model,f)
print(f"Trained model on {len(df)} synthetic examples; saved model.pkl")
print("Caution: this is a small synthetic demo dataset, not a real-world benchmark.")
