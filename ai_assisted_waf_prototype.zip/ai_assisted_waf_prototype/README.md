# AI-Assisted WAF — local prototype

A proof of concept combining regex-based attack indicators and a TF-IDF + Logistic Regression classifier. It includes a local web interface, event logging, unit tests, and a metrics script.

## Run
1. Install Python 3.10+.
2. In this folder, run `pip install -r requirements.txt`
3. Run `python train_model.py`
4. Run `python app.py` and open `http://127.0.0.1:8080`
5. In another terminal run `python -m unittest discover -s tests -v`
6. Run `python evaluate.py` to create `results/metrics.json` and `results/predictions.csv`.

Try benign `/products?id=25`, SQLi `/products?id=1%20OR%201=1`, XSS `/?q=%3Cscript%3Ealert(1)%3C/script%3E`, and command injection `/?file=%3Bcat%20/etc/passwd`.

**Important:** The included examples are synthetic and small. Report only the metrics generated on your machine and explicitly label them as synthetic-demo results. This is not a production WAF and should be run locally only.
