import unittest
from waf import normalize,detect_rules,inspect_request
class WAFTests(unittest.TestCase):
 def test_decode(self): self.assertIn("<script>",normalize("%3Cscript%3E"))
 def test_sqli(self): self.assertIn("SQLi",detect_rules("/x?id=1 OR 1=1"))
 def test_xss(self): self.assertIn("XSS",detect_rules("/?q=<script>alert(1)</script>"))
 def test_command(self): self.assertIn("Command Injection",detect_rules("/run?cmd=;cat /etc/passwd"))
 def test_benign(self): self.assertEqual(detect_rules("/products?id=25"),[])
 def test_block(self): self.assertEqual(inspect_request("/?q=<script>x</script>",model=None)["decision"],"BLOCK")
if __name__=="__main__": unittest.main()
