# Architecture
Client/tester → request normalization (URL decoding) → rule engine and ML classifier → hybrid policy → ALLOW/BLOCK → JSONL event log.

- Rule engine: simple regex indicators for SQLi, XSS, command injection.
- ML: character n-gram TF-IDF + Logistic Regression.
- Hybrid policy: block if any rule matches or model probability meets threshold.
- UI: local-only Python HTTP server at 127.0.0.1:8080; `/health` status endpoint.
- Evaluation: held-out split with accuracy, precision, recall, F1, confusion matrix, and prediction timing.

This is a proof of concept, not a reverse proxy or production WAF. The dataset is synthetic and small; metrics only demonstrate the evaluation pipeline. Future work: test on a suitable public dataset, integrate with a test application, expand request parsing and test coverage, and assess false positives/negatives on representative traffic.
